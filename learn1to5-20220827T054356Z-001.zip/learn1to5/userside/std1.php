<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>standard 1</title>
	  <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="std.css">
  </head>
<body style="background-color:skyblue;">
		<nav class="navbar navbar-inverse" style="background-color: #F4B41A;">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" style="color: #143D59;" href="#">Learn 1 to 5</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="#"><a href="index.php"align="right" style="color: #143D59;">Home</a></li>
        <li class="active"><a href="std1.php"align="right">Std:1</a></li>
        <li class="#"><a href="std2.php"align="right" style="color: #143D59;">Std:2</a></li>
        <li class="#"><a href="std3.php"align="right" style="color: #143D59;">Std:3</a></li>
        <li class="#"><a href="std4.php"align="right" style="color: #143D59;">Std:4</a></li>
        <li class="#"><a href="std5.php"align="right" style="color: #143D59;">Std:5</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">

        <li><a href="login.php" style="color: #143D59; background-color: white; border-radius: 8px;">
          <?php 

                if(empty($_SESSION)){
                  echo "Login";
                }else{
                  echo $_SESSION["user_name"];?>
                    
                                
                                

                                  <li><a href="logout.php" style="color: #143D59; background-color: white; border-radius: 8px;">logout</a></li>
                                    
                <?php }?>
              
        </a> 
</a></li>
      </ul>
    </div>
  </div>
</nav> 
<div class="display" align="center">
  <a class="HOVER">
    <span></span>
    <text><h1>ધોરણ:1</h1></text>
  </a>
 </div>
<ul class="list">
  <li><a href="1_ganit.php"> <span>ગણિત ગમ્મત</span></a></li>
  <li><a href="1_kalrav.php"> <span>કલરવ</span></a></li>
  <li><a href="1_kalkaliyo.php"><span>કલકલીયો</span></a></li>
  </ul>

</body>
</html>