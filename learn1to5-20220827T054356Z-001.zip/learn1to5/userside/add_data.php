<?php
	session_start();

    if (empty($_SESSION['user_name'])) {
        header("location:index.php");
    }
	include 'include.php';

    $sub=mysqli_query($conn,"select * from add_sub");
    $std=mysqli_query($conn,"select * from add_std");
	if(isset($_POST['sub_btn'])){


		$ch_name  =$_POST['ch_name'];
        $ch_num   =$_POST['ch_num'];
        $subject  =$_POST['subject'];
        $standard =$_POST['standard'];
        $ch_video =$_POST['ch_video'];
        $date     =date('d-m,y');

        $file_name  =$_FILES['ch_pdf']['name'];
        $file_size  =$_FILES['ch_pdf']['size'];
        $file_tmp   =$_FILES['ch_pdf']['tmp_name'];
        $file_type  =$_FILES['ch_pdf']['type'];
        move_uploaded_file($file_tmp,"upload/".$file_name);

        

		$type=mysqli_query($conn,"insert into add_data values('','".$ch_name."','".$ch_num."','".$file_name."','".$ch_video."','".$subject."','".$standard."','".$date."')");

        if ($type) {
            $success= "add success";
        }else{
            $failed = "error";
        }
	}
     
?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Add Data</title>
  <link rel="stylesheet" href="./style.css">

</head>
<body>
<!DOCTYPE html>
<html lang="en"> 
<head>
    <title>  
            Add Data
    </title>
    <script type="text/javascript">
        window.history.forward();
    </script>
    <script type="text/javascript">
        var host = "bootadmin.org";
        if ((host == window.location.host) && (window.location.protocol != "https:"))
            window.location.protocol = "https";
    </script>
    <link rel="stylesheet" href="https://bootadmin.org/style/vendor/library.min.css">
    <link rel="stylesheet" href="jquery-ui.min.css">
    <link rel="stylesheet" href="all.css">
    
    
    <link rel="stylesheet" href="style.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>

<body id="landing" class="sidebar-open">



<div class="sidebar">
    
    <ul id="sidebarCookie">
        <li class="nav-item">
            <a href="#" class="nav-link wave-effect nav-single">
                <i class=" icon-zap"></i>
                <span class="menu-title"><?php echo $_SESSION["user_name"];?></span>
            </a>
        </li>
        <li class="nav-item">
            <a href="home.php" class="nav-link wave-effect nav-single">
                <i class="feather icon-zap"></i>
                <span class="menu-title">Dashboard</span>
            </a>
        </li>
        <li class="nav-item">
            <a href="all_users.php" class="nav-link wave-effect nav-single">
                <i class="feather icon-calendar"></i>
                <span class="menu-title">All Users</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link wave-effect collapsed wave-effect" href="add_sub.php">
                <i class="feather icon-grid"></i>
                <span class="menu-title">add subject</span>
                
            </a>
            
        </li>
        <li class="nav-item">
            <a class="nav-link wave-effect collapsed wave-effect"  href="add_std.php">
                <i class="feather icon-grid"></i>
                <span class="menu-title">add standard</span>
            </a>
            
        </li>
        <li class="nav-item">
            <a class="nav-link wave-effect collapsed wave-effect"  href="add_data.php">
                <i class="feather icon-grid"></i>
                <span class="menu-title">add data</span>
            </a> 
        </li>
        <li class="spacer"></li>
        <li class="button-container">
            <a href="logout.php" class="btn btn-primary display-block"><i class="feather icon-download"></i> Log Out</a>
        </li>
    </ul>
</div>
<main style="margin-left: 70px;">
	<h1>Add subject Name</h1>
	<form method="post" enctype="multipart/form-data" style="margin-top: 30px; padding:10px;">
		<table>
            <tr>
                <td>Add Chapter name:<br><input type="text" name="ch_name"></td>
            </tr>
			<tr>
				<td>Add chapter number:<br><input type="text" name="ch_num"></td>
			</tr>
            <tr>
                <td>select pdf:<br><input type="file" name="ch_pdf"></td>
            </tr>
            <tr>
                <td>Add video link:<br><input type="text" name="ch_video"></td>
            </tr>
            <tr>
                <td>
                    select subject:<br>
                    <select name="subject">
                        <?php while ($row=mysqli_fetch_array($sub)) {
                    ?>
                        <option value="<?php echo $row["sub_name"];?>"><?php echo $row["sub_name"];?></option>
                        <?php }?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>
                    select standard:<br>
                    <select name="standard">
                        <?php while ($row1=mysqli_fetch_array($std)) {
                    ?>
                        <option value="<?php echo $row1["std_name"];?>"><?php echo $row1["std_name"];?></option>
                        <?php }?>
                    </select>
                </td>    
            </tr>
			<tr>
				<td><input type="submit" name="sub_btn" value="add data"></td>
			</tr>
            <tr>
            <?php if (isset($success)) { ?>
                    <td><div class="alert alert-success"> 
                            <?php echo $success; ?>
                    </div></td>
                <?php } ?>
                <?php if (isset($failed)) { ?>
                    <td><div class="alert alert-success"> 
                            <?php echo $failed; ?>
                    </div></td>
                <?php } ?>
            </tr>
		</table>
	</form>
</main>
<!-- Le Javascript -->
<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.min.js" integrity="sha256-eGE6blurk5sHj+rmkfsGYeKyZx3M4bG+ZlFyA7Kns7E=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://bootadmin.org/scripts/vendor/bootstrap.min.js"></script>
<script src="https://bootadmin.org/scripts/vendor/library.min.js"></script>



<script src="https://bootadmin.org/scripts/core/main.js"></script>

<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
    ga('create', 'UA-104952515-1', 'auto');
    ga('send', 'pageview');
</script>
</body>
</html>
<!-- partial -->
  <script  src="./script.js"></script>

</body>
</html>
