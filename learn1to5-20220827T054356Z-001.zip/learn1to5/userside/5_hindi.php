 <?php

    session_start();
   include 'include.php';

    if(empty($_SESSION["user_name"])){
    $result=mysqli_query($conn,"select * from add_data where standard=5 and subject=11 limit 4");
    }else{
      $result=mysqli_query($conn,"select * from add_data where standard=5 and subject=11");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>hindi</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap.min.css">
<style>
  section {
    padding-top: 4rem;
    padding-bottom: 5rem;
    
}
.wrap {
    display: flex;
    padding: 1rem 1rem 1rem 1rem;
    border-radius: 0.5rem;
    box-shadow: 7px 7px 30px -5px rgba(0,0,0,0.1);
    margin-bottom: 2rem;
}

.wrap:hover {
    background-image: linear-gradient(135deg,#6394ff 0%,#0a193b 100%);
    color: white;
}
</style>
</head>
<body style="background-color:skyblue;">

<nav class="navbar navbar-inverse" style="background-color: #F4B41A;">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" style="color: #143D59;" href="#">Learn 1 to 5</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="#"><a href="index.php"align="right" style="color: #143D59;">Home</a></li>
        <li class="#"><a href="std1.php"align="right" style="color: #143D59;">Std:1</a></li>
        <li class="#"><a href="std2.php"align="right" style="color: #143D59;">Std:2</a></li>
        <li class="#"><a href="std3.php"align="right" style="color: #143D59;">Std:3</a></li>
        <li class="#"><a href="std4.php"align="right" style="color: #143D59;">Std:4</a></li>
        <li class="active"><a href="std5.php"align="right">Std:5</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">

        <li><a href="login.php" style="color: #143D59; background-color: white; border-radius: 8px;">
          <?php 

                if(empty($_SESSION)){
                  echo "Login";
                }else{
                  echo $_SESSION["user_name"];?>
                    
                                
                                

                                  <li><a href="logout.php" style="color: #143D59; background-color: white; border-radius: 8px;">logout</a></li>
                                    
                <?php }?>
              
        </a> 
</a></li>
      </ul>
    </div>
  </div>
</nav>

        </a> 
</a></li>
      </ul>
    </div>
  </div>
</nav>
 <section>
    <div class="container">
      <div class="row">
        <?php while($row=mysqli_fetch_array($result)) {?>
          <div class="col-md-6 text-center" style="font-size: 22px; font-weight: 700; background-color: #fff; border-radius: 30px;">
            <h1><?php echo $row['ch_name'];?>
            <?php echo ":"; echo $row['ch_num'];?></h1>  <br>
             <a href="./admin/upload/<?php echo $row['ch_pdf'];?>" target="_blank">
             <img src="apps.34961.13510798887621962.47b62c4c-a0c6-4e3c-87bb-509317d9c364 - Copy.png" width="200" height="180"></a><br>
             <iframe width="300" height="200" src="<?php echo $row['ch_video'];?>" frameborder="0" allow="autoplay;" allowfullscreen></iframe>
          </div>
        <?php }?>
      </div>
    </div>
</section>

</body>
</html>
