<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>standard 4</title>
	  <link rel="stylesheet" href="bootstrap.min.css">
     <link rel="stylesheet" type="text/css" href="std.css">
<style>
  section {
    padding-top: 4rem;
    padding-bottom: 5rem;
    
}
.wrap {
    display: flex;
    padding: 1rem 1rem 1rem 1rem;
    border-radius: 0.5rem;
    box-shadow: 7px 7px 30px -5px rgba(0,0,0,0.1);
    margin-bottom: 2rem;
}

.wrap:hover {
    background-image: linear-gradient(135deg,#6394ff 0%,#0a193b 100%);
    color: white;
}
</style>
</head>
<body style="background-color:skyblue;">
		<nav class="navbar navbar-inverse" style="background-color: #F4B41A;">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" style="color: #143D59;" href="#">Learn 1 to 5</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="#"><a href="index.php"align="right" style="color: #143D59;">Home</a></li>
        
        <li class="#"><a href="std1.php"align="right" style="color: #143D59;">Std:1</a></li>
        <li class="#"><a href="std2.php"align="right" style="color: #143D59;">Std:2</a></li>
        <li class="#"><a href="std3.php"align="right" style="color: #143D59;">Std:3</a></li>
        <li class="active"><a href="std4.php"align="right">Std:4</a></li>
        <li class="#"><a href="std5.php"align="right" style="color: #143D59;">Std:5</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">

<li><a href="login.php" style="color: #143D59; background-color: white; border-radius: 8px;">
          <?php 

                if(empty($_SESSION)){
                  echo "Login";
                }else{
                  echo $_SESSION["user_name"];?>
                    
                                
                                

                                  <li><a href="logout.php" style="color: #143D59; background-color: white; border-radius: 8px;">logout</a></li>
                                    
                <?php }?>
              
        </a> 
</a></li>
      </ul>
    </div>
  </div>
</nav>
<div class="display" align="center">
  <a class="HOVER">
    <span></span>
    <text><h1>ધોરણ:4</h1></text>
  </a>
 </div>
<ul class="list">
  <li><a href="4_gammat.php"> <span>ગણિત ગમ્મત</span></a></li>
  <li><a href="4_environment.php"> <span>પર્યાવરણ</span></a></li>
  <li><a href="4_english.php"> <span>અંગ્રેજી</span></a></li>
  <li><a href="4_hindi.php"> <span>હિન્દી</span></a></li>
  <li><a href="4_gujarati.php"> <span>ગુજરાતી</span></a></li>
  <li><a href="4_patrango.php"> <span>પેટ્રાંગો</span></a></li>
  </ul> 
</body>
</html>